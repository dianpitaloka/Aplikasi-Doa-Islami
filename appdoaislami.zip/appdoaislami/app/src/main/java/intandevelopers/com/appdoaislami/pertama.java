package intandevelopers.com.appdoaislami;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class pertama extends AppCompatActivity {

    private Button mulaiBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_pertama );

        mulaiBtn = findViewById ( R.id.pertamaBtn );

        mulaiBtn.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent menuIntent = new Intent ( pertama.this, menu.class );
                startActivity ( menuIntent );
            }
        } );
    }
}
